"""
app.py - Main Flask Application
College Placement Prediction System
"""

from flask import (Flask, render_template, request, redirect,
                   url_for, session, flash, jsonify, Response)
import sqlite3, csv, io, os
from functools import wraps
from utils.helpers import predict_placement, get_model_info, init_db

app = Flask(__name__)
app.secret_key = 'placement_secret_2024'

DB_PATH = os.path.join('database', 'placement.db')
os.makedirs('database', exist_ok=True)
init_db(DB_PATH)

# ─── DB helper ───────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# ─── Auth decorator ──────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'admin' not in session:
            flash('Please login first.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

# ─── PUBLIC ROUTES ───────────────────────────
@app.route('/')
def index():
    db = get_db()
    total     = db.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    placed    = db.execute("SELECT COUNT(*) FROM students WHERE prediction=1").fetchone()[0]
    not_placed= db.execute("SELECT COUNT(*) FROM students WHERE prediction=0").fetchone()[0]
    db.close()
    return render_template('index.html', total=total, placed=placed, not_placed=not_placed)

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    result = None
    form_data = {}
    if request.method == 'POST':
        form_data = request.form.to_dict()
        try:
            placed, prob = predict_placement(form_data)
            result = {
                'placed': placed,
                'probability': prob,
                'status': 'Likely To Be Placed' if placed else 'Needs Improvement',
                'color': 'success' if placed else 'danger'
            }
            # Save to DB
            db = get_db()
            try:
                db.execute('''
                    INSERT INTO students
                    (name,roll_no,email,branch,cgpa,tenth_percentage,twelfth_percentage,
                     aptitude_score,coding_score,communication_score,internship,projects,backlogs,
                     prediction,probability)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ''', (
                    form_data.get('name',''), form_data.get('roll_no',''),
                    form_data.get('email',''), form_data.get('branch',''),
                    form_data['cgpa'], form_data['tenth_percentage'],
                    form_data['twelfth_percentage'], form_data['aptitude_score'],
                    form_data['coding_score'], form_data['communication_score'],
                    form_data['internship'], form_data['projects'],
                    form_data['backlogs'], placed, prob
                ))
                db.commit()
            except sqlite3.IntegrityError:
                db.execute('''
                    UPDATE students SET
                      cgpa=?, tenth_percentage=?, twelfth_percentage=?,
                      aptitude_score=?, coding_score=?, communication_score=?,
                      internship=?, projects=?, backlogs=?,
                      prediction=?, probability=?
                    WHERE roll_no=?
                ''', (
                    form_data['cgpa'], form_data['tenth_percentage'],
                    form_data['twelfth_percentage'], form_data['aptitude_score'],
                    form_data['coding_score'], form_data['communication_score'],
                    form_data['internship'], form_data['projects'],
                    form_data['backlogs'], placed, prob,
                    form_data.get('roll_no','')
                ))
                db.commit()
            db.close()
        except Exception as e:
            flash(f'Prediction error: {str(e)}', 'danger')
    return render_template('prediction.html', result=result, form_data=form_data)

@app.route('/dashboard')
def dashboard():
    db = get_db()
    total      = db.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    placed     = db.execute("SELECT COUNT(*) FROM students WHERE prediction=1").fetchone()[0]
    not_placed = db.execute("SELECT COUNT(*) FROM students WHERE prediction=0").fetchone()[0]
    avg_cgpa   = db.execute("SELECT ROUND(AVG(cgpa),2) FROM students").fetchone()[0] or 0
    max_cgpa   = db.execute("SELECT MAX(cgpa) FROM students").fetchone()[0] or 0

    branches = db.execute('''
        SELECT branch,
               COUNT(*) as total,
               SUM(CASE WHEN prediction=1 THEN 1 ELSE 0 END) as placed
        FROM students GROUP BY branch ORDER BY total DESC
    ''').fetchall()

    recent = db.execute(
        "SELECT * FROM students ORDER BY created_at DESC LIMIT 5"
    ).fetchall()

    cgpa_dist = db.execute('''
        SELECT
          CASE
            WHEN cgpa < 6 THEN "Below 6"
            WHEN cgpa < 7 THEN "6-7"
            WHEN cgpa < 8 THEN "7-8"
            WHEN cgpa < 9 THEN "8-9"
            ELSE "9+"
          END as range,
          COUNT(*) as cnt
        FROM students GROUP BY range ORDER BY range
    ''').fetchall()

    db.close()
    return render_template('dashboard.html',
        total=total, placed=placed, not_placed=not_placed,
        avg_cgpa=avg_cgpa, max_cgpa=max_cgpa,
        branches=branches, recent=recent, cgpa_dist=cgpa_dist
    )

@app.route('/statistics')
def statistics():
    db = get_db()
    model_info = get_model_info()
    branches = db.execute('''
        SELECT branch, COUNT(*) as total,
               SUM(CASE WHEN prediction=1 THEN 1 ELSE 0 END) as placed,
               ROUND(AVG(cgpa),2) as avg_cgpa
        FROM students GROUP BY branch
    ''').fetchall()
    db.close()
    return render_template('statistics.html', model_info=model_info, branches=branches)

# ─── ADMIN AUTH ──────────────────────────────
@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'admin' in session:
        return redirect(url_for('students'))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        admin = db.execute(
            "SELECT * FROM admins WHERE username=? AND password=?",
            (username, password)
        ).fetchone()
        db.close()
        if admin:
            session['admin'] = username
            flash(f'Welcome back, {username}!', 'success')
            return redirect(url_for('students'))
        flash('Invalid credentials.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('admin', None)
    flash('Logged out successfully.', 'info')
    return redirect(url_for('login'))

# ─── ADMIN STUDENT CRUD ───────────────────────
@app.route('/admin/students')
@login_required
def students():
    q      = request.args.get('q', '')
    branch = request.args.get('branch', '')
    placed = request.args.get('placed', '')
    db     = get_db()

    query = "SELECT * FROM students WHERE 1=1"
    params = []
    if q:
        query += " AND (name LIKE ? OR roll_no LIKE ? OR email LIKE ?)"
        params.extend([f'%{q}%', f'%{q}%', f'%{q}%'])
    if branch:
        query += " AND branch=?"
        params.append(branch)
    if placed != '':
        query += " AND prediction=?"
        params.append(int(placed))
    query += " ORDER BY created_at DESC"

    student_list = db.execute(query, params).fetchall()
    branches     = db.execute("SELECT DISTINCT branch FROM students ORDER BY branch").fetchall()
    db.close()
    return render_template('students.html',
        students=student_list, branches=branches,
        q=q, sel_branch=branch, sel_placed=placed
    )

@app.route('/admin/students/add', methods=['GET', 'POST'])
@login_required
def add_student():
    if request.method == 'POST':
        fd = request.form
        try:
            placed, prob = predict_placement(fd)
            db = get_db()
            db.execute('''
                INSERT INTO students
                (name,roll_no,email,branch,cgpa,tenth_percentage,twelfth_percentage,
                 aptitude_score,coding_score,communication_score,internship,projects,backlogs,
                 prediction,probability)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ''', (fd['name'], fd['roll_no'], fd['email'], fd['branch'],
                  fd['cgpa'], fd['tenth_percentage'], fd['twelfth_percentage'],
                  fd['aptitude_score'], fd['coding_score'], fd['communication_score'],
                  fd['internship'], fd['projects'], fd['backlogs'], placed, prob))
            db.commit()
            db.close()
            flash(f'Student {fd["name"]} added successfully!', 'success')
            return redirect(url_for('students'))
        except sqlite3.IntegrityError:
            flash('Roll number already exists.', 'danger')
        except Exception as e:
            flash(f'Error: {str(e)}', 'danger')
    return render_template('add_student.html')

@app.route('/admin/students/edit/<int:sid>', methods=['GET', 'POST'])
@login_required
def edit_student(sid):
    db = get_db()
    student = db.execute("SELECT * FROM students WHERE id=?", (sid,)).fetchone()
    if not student:
        flash('Student not found.', 'danger')
        return redirect(url_for('students'))

    if request.method == 'POST':
        fd = request.form
        try:
            placed, prob = predict_placement(fd)
            db.execute('''
                UPDATE students SET
                  name=?, roll_no=?, email=?, branch=?,
                  cgpa=?, tenth_percentage=?, twelfth_percentage=?,
                  aptitude_score=?, coding_score=?, communication_score=?,
                  internship=?, projects=?, backlogs=?,
                  prediction=?, probability=?
                WHERE id=?
            ''', (fd['name'], fd['roll_no'], fd['email'], fd['branch'],
                  fd['cgpa'], fd['tenth_percentage'], fd['twelfth_percentage'],
                  fd['aptitude_score'], fd['coding_score'], fd['communication_score'],
                  fd['internship'], fd['projects'], fd['backlogs'], placed, prob, sid))
            db.commit()
            db.close()
            flash('Student updated successfully!', 'success')
            return redirect(url_for('students'))
        except Exception as e:
            flash(f'Error: {str(e)}', 'danger')
    db.close()
    return render_template('edit_student.html', student=student)

@app.route('/admin/students/delete/<int:sid>', methods=['POST'])
@login_required
def delete_student(sid):
    db = get_db()
    db.execute("DELETE FROM students WHERE id=?", (sid,))
    db.commit()
    db.close()
    flash('Student deleted.', 'info')
    return redirect(url_for('students'))

@app.route('/admin/export')
@login_required
def export_csv():
    db = get_db()
    rows = db.execute("SELECT * FROM students ORDER BY created_at DESC").fetchall()
    db.close()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID','Name','Roll No','Email','Branch','CGPA',
                     '10th%','12th%','Aptitude','Coding','Communication',
                     'Internship','Projects','Backlogs','Prediction','Probability','Created At'])
    for r in rows:
        pred = 'Placed' if r['prediction'] == 1 else ('Not Placed' if r['prediction'] == 0 else 'N/A')
        writer.writerow([
            r['id'], r['name'], r['roll_no'], r['email'], r['branch'],
            r['cgpa'], r['tenth_percentage'], r['twelfth_percentage'],
            r['aptitude_score'], r['coding_score'], r['communication_score'],
            r['internship'], r['projects'], r['backlogs'],
            pred, r['probability'], r['created_at']
        ])
    output.seek(0)
    return Response(output, mimetype='text/csv',
                    headers={'Content-Disposition': 'attachment;filename=students_export.csv'})

# ─── API ENDPOINTS ────────────────────────────
@app.route('/api/dashboard-data')
def api_dashboard_data():
    db = get_db()
    branches = db.execute('''
        SELECT branch, COUNT(*) as total,
               SUM(CASE WHEN prediction=1 THEN 1 ELSE 0 END) as placed
        FROM students GROUP BY branch
    ''').fetchall()
    cgpa_dist = db.execute('''
        SELECT
          CASE WHEN cgpa<6 THEN "Below 6" WHEN cgpa<7 THEN "6-7"
               WHEN cgpa<8 THEN "7-8"    WHEN cgpa<9 THEN "8-9" ELSE "9+"
          END as rng, COUNT(*) as cnt
        FROM students GROUP BY rng ORDER BY rng
    ''').fetchall()
    total  = db.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    placed = db.execute("SELECT COUNT(*) FROM students WHERE prediction=1").fetchone()[0]
    db.close()
    return jsonify({
        'branches': [dict(r) for r in branches],
        'cgpa_dist': [dict(r) for r in cgpa_dist],
        'total': total, 'placed': placed, 'not_placed': total - placed
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
