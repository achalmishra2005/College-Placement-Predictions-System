"""
utils/helpers.py - Helper utilities
College Placement Prediction System
"""

import pickle
import pandas as pd
import sqlite3
import os

MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'model.pkl')

FEATURE_COLS = [
    'cgpa', 'tenth_percentage', 'twelfth_percentage',
    'aptitude_score', 'coding_score', 'communication_score',
    'internship', 'projects', 'backlogs',
    'academic_avg', 'skill_avg', 'experience_score'
]

def load_model():
    with open(MODEL_PATH, 'rb') as f:
        return pickle.load(f)

def predict_placement(data: dict):
    model_data = load_model()
    pipeline   = model_data['pipeline']

    cgpa  = float(data['cgpa'])
    tenth = float(data['tenth_percentage'])
    twelfth= float(data['twelfth_percentage'])
    apt   = float(data['aptitude_score'])
    code  = float(data['coding_score'])
    comm  = float(data['communication_score'])
    intern= int(data['internship'])
    proj  = int(data['projects'])
    back  = int(data['backlogs'])

    row = {
        'cgpa': cgpa, 'tenth_percentage': tenth, 'twelfth_percentage': twelfth,
        'aptitude_score': apt, 'coding_score': code, 'communication_score': comm,
        'internship': intern, 'projects': proj, 'backlogs': back,
        'academic_avg': (cgpa * 10 + tenth + twelfth) / 3,
        'skill_avg': (apt + code + comm) / 3,
        'experience_score': intern * 10 + proj * 5
    }
    X = pd.DataFrame([row], columns=FEATURE_COLS)

    prob   = pipeline.predict_proba(X)[0][1]
    placed = int(pipeline.predict(X)[0])
    return placed, round(float(prob) * 100, 2)

def get_model_info():
    model_data = load_model()
    return {
        'model_name': model_data['model_name'],
        'accuracy':   round(model_data['accuracy']  * 100, 2),
        'precision':  round(model_data['precision'] * 100, 2),
        'recall':     round(model_data['recall']    * 100, 2),
        'f1':         round(model_data['f1']        * 100, 2),
        'all_results': {
            k: {m: round(v * 100, 2) for m, v in r.items()}
            for k, r in model_data['all_results'].items()
        }
    }

def init_db(db_path):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.executescript('''
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            roll_no TEXT UNIQUE NOT NULL,
            email TEXT,
            branch TEXT,
            cgpa REAL,
            tenth_percentage REAL,
            twelfth_percentage REAL,
            aptitude_score INTEGER,
            coding_score INTEGER,
            communication_score INTEGER,
            internship INTEGER DEFAULT 0,
            projects INTEGER DEFAULT 0,
            backlogs INTEGER DEFAULT 0,
            prediction INTEGER DEFAULT NULL,
            probability REAL DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        );
        INSERT OR IGNORE INTO admins (username, password) VALUES ("admin", "admin123");
    ''')
    conn.commit()
    conn.close()
